#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define DEVDIR  "/sys/devices/platform/ff100000.saradc/iio:device0"

int adcReadRaw(int ch)
{
	int ret = -1;
	if (ch>=0 && ch<=5) {
		char buf[128];
		snprintf(buf, 128, DEVDIR"/in_voltage%d_raw", ch);
		int fd = open(buf, O_RDONLY);
		if (fd > 0) {
			ret = read(fd, buf, 128);
			if (ret > 0) {
				buf[ret] = '\0';
				ret = atoi(buf);
			}
			close(fd);
		}
	}
	return ret;
}

float adcReadCh0Volage(void)
{
	int t = adcReadRaw(0);
	if (t >= 0) {
		float v = t * 1.8f / 1023;
		float vin = v;
		#define R1 10000.0f
		#define R2 10000.0f
		#define R3 10000.0f
		/* 10K 1.8v*/
		#if 0
		float i3, i1, i2;
		i3 = (1.8 - v)/R3;
		i1 = v / R1;
		i2 = i1 - i3;
		vin = v + i2 * R2;
		#endif
		return vin;
	}
	return -1;
}
