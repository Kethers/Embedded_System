#ifndef __OLED_H__
#define __OLED_H__

void oledPoint(int x, int y, int st);
void oledDraw(char *buf);
void oledClear(void);
void oledFlush(void);
void oledInit(void);

#endif
