#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include "adc.h"



int adcTest(int argc, char *argv[])
{
	while (1) {
		float v =  adcReadCh0Volage();
		printf("adc ch 0 v:%.2f \r\n", v);
		msleep(1000);
	}
	return 0;
}
