#ifndef __PWMLED_H__
#define __PWMLED_H__

void pwmLedPeriod(int p);
void pwmLedValue(int v);
void pwmLedPolarity(int p);
void pwmLedEnable(int en);
void pwmLedInit(void);

#endif
