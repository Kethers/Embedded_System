#ifndef __LEDS_H__
#define __LEDS_H__

void ledInit(void);
void ledOn(int leds);
void ledOff(int leds);
#endif
