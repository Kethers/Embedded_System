#ifndef __FFT_H__
#define __FFT_H__
void dft(float *in, float *out, int n);
#endif
