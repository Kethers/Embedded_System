#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>
#include <unistd.h>
#include <pthread.h>  
#include <sys/socket.h>
#include <netinet/in.h>
#include <math.h>
#include <linux/soundcard.h>
#include "font.h"
#include "key.h"
#include "oled.h"
#include "adc.h"
#include "utils.h"
#include "fft.h"
#include "led8x8.h"
#include "leds.h"
#define ALSA_PCM_NEW_HW_PARAMS_API
#include <alsa/asoundlib.h>

static volatile int audioBufLen = 0;
static char audioBuf[2048];
#define PSIZE 512
#define SAMPLE 22000
float outv[PSIZE];

//static int style = 0;
extern int sysStyle;
#define STEPF (SAMPLE / (PSIZE/2))
#define F(i)	((i)*STEPF)
#define RF(x)	(1+((x)/STEPF))

static void showLed(void)
{
	static int max = 0;
	int sum = 0;
	for (int i=1; i<8; i++) {
		//if (outv[i]*0.7>max) max = outv[i];
		sum += outv[RF(100+(i*(2500/8)))]/32;
	}
	int f = sum / 8;
	if (f > max) max+=1;
	else max -= 1;
	if (max < 0) max = 0;
	if (max > 4) max = 4;
	for (int i=0; i<4; i++) {
		if (i < max) {
			ledOn(1<<i);
		} else ledOff(1<<i);
	}
}

static void showled8x8(void)
{
	static int lastVS[8];
	for (int i=0; i<8; i++) {
		//1+i*((PSIZE/2)/8)
		int v = (1+(int)outv[RF(100+i*((SAMPLE/2)/10))]/32); //30-10k
		if (v > 8) v = 8;
		for (int j=0; j<8; j++) {
			led8x8Point(i, 7-j, v>j);
		}
		if (v > lastVS[i]) lastVS[i] = v;
		else {
			
			if (sysStyle == 1) {
				led8x8Point(i, 8-lastVS[i], 1);
			}else if (sysStyle == 2) {
				for (int j=0; j<lastVS[i]; j++) {
					led8x8Point(i, 8-lastVS[i]+j, 1);
				}
			}else {
				sysStyle = 0;
			}
		}
	}
	{
		static long ms;
		if (sysms() - ms > 200){
			for (int i=0; i<8; i++) {
				if (lastVS[i] > 1) lastVS[i] -= 1;
			}
			ms = sysms();
		}
	}
	led8x8Flush();
}

static void show96x32(void)
{

	static int lastVS[96];
	
	for (int i=0; i<96; i++) {
		int v = (1+(int)outv[RF(100+i*((SAMPLE/2)/100))]/8);
		if (v > 32) v = 32;
		for (int j=0; j<32; j++) {
			oledPoint(i, 31-j, v>j);
		}
		if (v > lastVS[i]) lastVS[i] = v;
		else {
			
			if (sysStyle == 1) {
				oledPoint(i, 32-lastVS[i], 1);
			}else if (sysStyle == 2) {
				for (int j=0; j<lastVS[i]; j++) {
					oledPoint(i, 32-lastVS[i]+j, 1);
				}
			}else {
				sysStyle = 0;
			}
		}
	}
	{
		static long ms;
		if (sysms() - ms >= 100){
			for (int i=0; i<96; i++) {
				if (lastVS[i] > 1) lastVS[i] -= 1;
			}
			ms = sysms();
		}
	}
	oledFlush();
}

void* threadAudioIn(void *arg)
{
	int sock_fd;
    char rcv_buff[2048];
    struct sockaddr_in client_addr;
    struct sockaddr_in server_addr;
    int client_len;
    int rcv_num = -1;
	int *parg = arg;

    if ((sock_fd = socket(AF_INET, SOCK_DGRAM,0)) < 0)
    {
        perror("socket create error\n");
        exit(1);
    }

    memset(&server_addr,0,sizeof(struct sockaddr_in));
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(27350);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    client_len = sizeof(struct sockaddr_in);

    if (bind(sock_fd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in)) < 0)
    {
        perror("bind error.\n");
        exit(1);
    }
    long lastT = sysms();
    while (*parg)
    {
        rcv_num= recvfrom(sock_fd, rcv_buff, sizeof(rcv_buff), 0, (struct sockaddr*)&client_addr, &client_len);
        if (rcv_num>0)
        {
			if (audioBufLen == 0/*&& sysms()-lastT>=50*/) {
				lastT = sysms();
				memcpy(audioBuf, rcv_buff, rcv_num);
				audioBufLen = rcv_num;
			}
        }
        else
        {
            perror("recv error\n");
            break;
        }
    }
    close(sock_fd);
	return NULL;
}

void* threadAudioIn2(void *arg)
{
	int *parg = arg;
	//long loops;
	int rc;
	int size;
	snd_pcm_t *handle;
	snd_pcm_hw_params_t *params;
	unsigned int val;
	int dir;
	snd_pcm_uframes_t frames;
	char *buffer;
	/* Open PCM device for recording (capture). */
	rc = snd_pcm_open(&handle, "default",
		SND_PCM_STREAM_CAPTURE, 0);
	if (rc < 0) {
		fprintf(stderr,
		"unable to open pcm device: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Allocate a hardware parameters object. */
	snd_pcm_hw_params_alloca(&params);
	/* Fill it in with default values. */
	snd_pcm_hw_params_any(handle, params);
	/* Set the desired hardware parameters. */
	/* Interleaved mode */
	rc = snd_pcm_hw_params_set_access(handle, params,
		SND_PCM_ACCESS_RW_INTERLEAVED);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set snd_pcm_hw_params_set_access: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Signed 16-bit little-endian format */
	rc = snd_pcm_hw_params_set_format(handle, params,
		/*SND_PCM_FORMAT_S16_LE*/SND_PCM_FORMAT_U8);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set snd_pcm_hw_params_set_format: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Two channels (stereo) */
	rc = snd_pcm_hw_params_set_channels(handle, params, 1);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set snd_pcm_hw_params_set_channels: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* 44100 bits/second sampling rate (CD quality) */
	val = SAMPLE;
	rc = snd_pcm_hw_params_set_rate_near(handle, params,
		&val, &dir);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set snd_pcm_hw_params_set_rate_near: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Set period size to 32 frames. */
	frames = PSIZE;
	rc = snd_pcm_hw_params_set_period_size_near(handle,
		params, &frames, &dir);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set hw parameters: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Write the parameters to the driver */
	rc = snd_pcm_hw_params(handle, params);
	if (rc < 0) {
		fprintf(stderr,
		"unable to set hw parameters: %s\n",
		snd_strerror(rc));
		exit(1);
	}
	/* Use a buffer large enough to hold one period */
	snd_pcm_hw_params_get_period_size(params,
		&frames, &dir);
	size = frames * 1;//4; /* 2 bytes/sample, 2 channels */
	printf("buff size %d\r\n");
	buffer = (char *) malloc(size);
	/* We want to loop for 5 seconds */
	snd_pcm_hw_params_get_period_time(params,
		&val, &dir);
	//loops = 5000000 / val;
	printf("pppp t %d\r\n", val);
	while (*parg) {
		//loops--;
		rc = snd_pcm_readi(handle, buffer, frames);
		if (rc == -EPIPE) {
			/* EPIPE means overrun */
			fprintf(stderr, "overrun occurred\n");
			snd_pcm_prepare(handle);
		} else if (rc < 0) {
			fprintf(stderr,
			"error from read: %s\n",
			snd_strerror(rc));
		} else if (rc != (int)frames) {
			fprintf(stderr, "short read, read %d frames\n", rc);
		} else {
			if (audioBufLen == 0/*&& sysms()-lastT>=50*/) {
				//lastT = sysms();
				//memcpy(audioBuf, buffer, size);
				//audioBufLen = size;
			}
		}
		//rc = write(1, buffer, size);
		if (rc != size)
			fprintf(stderr,
				"short write: wrote %d bytes\n", rc);
	}
	snd_pcm_drain(handle);
	snd_pcm_close(handle);
	free(buffer);
	return 0;
}

void* threadFft(void *arg)
{
	float in[PSIZE*2], out[PSIZE*2];
	int *parg = arg;
	pthread_t pt;
	
	sysStyle = 0;
	
	//pthread_create( &pt, NULL, threadAudioIn2, arg );
		
	ledInit();
	
	while (*parg) {
		if (audioBufLen > 0 ) {
			if (audioBufLen < PSIZE){
				audioBufLen = 0;
				continue;
			}
			long bt = sysms();
			for (int i=0; i<PSIZE; i++) {
				in[i*2+0] = audioBuf[i];
				in[i*2+1] = 0;
			}
			dft(in, out, PSIZE);
			long et = sysms();
			for (int i=1; i<PSIZE; i++) {
				float v1 = out[i*2+0];
				float v2 = out[i*2+1];
				outv[i] = sqrt(v1*v1+v2*v2);
			}
			showled8x8();
			show96x32();
			showLed();
			audioBufLen = 0;
		} else msleep(1);
	}
	//pthread_join(pt, NULL);
}

void* threadRecoder(void *arg)
{
	int pid;
	char cmd[64];
	snprintf(cmd, 64, "arecord -r %d -f U8 -t raw | ./udpfw &", SAMPLE);
	system(cmd);
}
