#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define DEVDIR "/sys/bus/i2c/devices/i2c-2/2-003c"
/*
	字节按列排
 */
static char ram[4][96];

#if 0
static void dumRam(void)
{
	//printf("ram\r\n");
	printf("\033[H");
	//printf("\r\n");
	for (int i=0; i<32; i++) {
		//printf("%02d ", i);
		for (int j=0; j<96; j++) {
			if (ram[i/8][j] & (1<<(i%8))) {
				printf("*");
			} else {
				printf(" ");
			}					
		}
		printf("\r\n");
	}
	//printf("ram end\r\n");
}
#else
static void dumRam(void)
{
}
#endif
void oledPoint(int x, int y, int st)
{
	if (x>=0 && x<96){
		if (y>=0 && y<32) {
			ram[y/8][x] = ram[y/8][x] & ~(1<<(y%8));
			if (st != 0) {
				ram[y/8][x] = ram[y/8][x] | (1<<(y%8));
			}
		}
	}
}
void oledDraw(char *buf)
{
	memcpy(ram, buf, sizeof ram);
}
void oledClear(void)
{
	memset(ram, 0, sizeof ram);
}
void oledFlush(void)
{
	int fd = open(DEVDIR"/buffer", O_WRONLY);
	if (fd >= 0) {
		write(fd, ram, sizeof ram);
		close(fd);
	}
	dumRam();	
}
void oledInit(void)
{
	if (0 == access("ssd1316.ko",F_OK)){
		int ret = system("lsmod | grep ssd1316");
		if (ret != 0) {
			system("insmod ssd1316.ko");
		}
	}
	memset(ram, 0, sizeof ram);
	oledFlush();
}
