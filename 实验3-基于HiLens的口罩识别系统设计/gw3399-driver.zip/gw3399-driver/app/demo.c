#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>
#include <unistd.h>
#include <pthread.h>  
#include <sys/socket.h>
#include <netinet/in.h>
#include <math.h>
#include "font.h"
#include "key.h"
#include "oled.h"
#include "adc.h"
#include "utils.h"
#include "fft.h"
#include "led8x8.h"
#include "pwmLed.h"
#include "adc.h"
#include "leds.h"

/*
 * 功能1 ：跑马灯 /ADC
 * 功能2 ：频谱
 * 功能3 ：PWM Led
 */
#define HW_VER "0.0.1"
#define SW_VER "0.0.2"


int sysFun = 0;
int sysStyle = 0;

void* threadFft(void *arg);
void* threadRecoder(void *arg);
void* threadAudioIn(void *arg);
void *ledsDemo(void *arg);

static void showFont16Center(char *str)
{
	int len = strlen(str)*8;
	int offx = 0;
	if (len < 96) offx = (96-len)/2;
	fontShow16(offx, 8, str, oledPoint);
}
void* Fun1(void* arg)
{
	int *parg = arg;
	int offx = 96;
	int offy = 8;
	int lastStyle = 0;
	pthread_t pt;
	
	sysStyle = 0;
	lastStyle = 0;
	oledClear();
	showFont16Center("Welcome!");
	oledFlush();
	led8x8Clear();
	led8x8Flush();

	pthread_create(&pt, NULL, ledsDemo, arg );
	
	sleep(1);
	int speed = 5;
	float v = adcReadCh0Volage();
	time_t t = time(NULL);
	while (*parg) {
		char buf[32];
		time_t t2 = time(NULL);
		if (t2 != t){
			v = adcReadCh0Volage();
			t = t2;
		}
		
		oledClear();
		if (sysStyle % 2 == 1) {
			snprintf(buf, sizeof buf, "ADC: %.2fV", v);
		} else {
			snprintf(buf, sizeof buf, "TVOC: %.1fmg/m3", v*0.2f);
		}
		//showFont16Center(buf);
		int y = (strlen(buf)*8);
		if (sysStyle > 2) sysStyle = 0;
		if (lastStyle != sysStyle) {
			lastStyle = sysStyle;
			if (sysStyle == 0) {
				offx = 96;
				offy = 8;
			}
			if (sysStyle == 1) {
				offx = (96-strlen(buf)*8)/2;
				offy = 32;
			}
			if (sysStyle == 2) {
				offx = (96-strlen(buf)*8)/2;
				offy = -16;
			}
		}
		if (sysStyle == 0) {
			offx -= speed;
			if (offx < -y){
				offx = 96;
			}
		} else if (sysStyle == 1) {
			offy -= 1;
			if (offy < 8) offy=32;
		} else if (sysStyle == 2){
			offy += 1;
			if (offy>8)offy = -16;
		}
		fontShow16(offx, offy, buf, oledPoint);
		oledFlush();

		msleep(50);
	}	
	
	oledClear();
	oledFlush();
	pthread_join(pt, NULL);
	return NULL;
}
void* Fun3(void* arg)
{
	int *parg = arg;
	void pwmLedSin(int Tms, int*run);
	void led8x8Face(int i);
	void *pwmLedThread(void *arg);
	
	sysStyle = 0;
	
	oledClear();
	led8x8Face(sysStyle);
	ledOff(0xff);
	pwmLedInit();
	pwmLedPeriod(1000);
	pwmLedEnable(2);

	oledFlush();
	led8x8Flush();
	pthread_t pt;
	pthread_create(&pt, NULL, pwmLedThread, arg );
	int lastStyle = 0;
	while (*parg) {
		if (sysStyle > 7) sysStyle = 0;
		if (lastStyle != sysStyle) {
			lastStyle = sysStyle;
			led8x8Face(sysStyle);
			led8x8Flush();
		}
		msleep(10);
	}
	pthread_join(pt, NULL);
	pwmLedEnable(0);
	ledOff(0xff);
	return NULL;
}
void switchFun(void)
{
	static  int isRun = 0;
	static pthread_t pt;
	if (isRun != 0) {
		isRun = 0;
		pthread_join(pt, NULL);
	}
	if (sysFun == 0) {
		isRun = 1;
		memset(&pt, 0, sizeof pt);
		pthread_create(&pt, NULL, Fun1, &isRun );	
	} else if (sysFun == 1) {
		isRun = 1;
		memset(&pt, 0, sizeof pt);
		pthread_create(&pt, NULL, threadFft, &isRun );
	} else if (sysFun == 2) {
		isRun = 1;
		memset(&pt, 0, sizeof pt);
		pthread_create(&pt, NULL, Fun3, &isRun );
	}
	sysFun += 1;
	if (sysFun >= 3) sysFun = 0;
}

static void* threadKey(void* arg)
{
	struct input_event evtKey;
	while (1) {
		evtKey = keyCheck();
		if (evtKey.type==EV_KEY) {
			if (evtKey.code == KEY_1) {
				//key1 = evtKey.value;
				if (evtKey.value == 0) {
					switchFun();
				}
			}
			if (evtKey.code == KEY_2) {
				//key2 = evtKey.value;
				if (evtKey.value == 0) {
					sysStyle += 1;
				}
			}
			/*if (evtKey.code == KEY_POWER){
				if (evtKey.value == 0) {
					switchFun();
				}
			}*/
		}
	}
	keyDeInit();
	return NULL;
}

static void* threadUdp(void* arg)
{
	int *parg = arg;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	int client_len;
	char rcv_buff[1024];
	char send_buff[1024];
	int rcv_num;
	int sock_fd;
	
	if ((sock_fd = socket(AF_INET, SOCK_DGRAM,0)) < 0) {
        perror("socket create error\n");
        exit(1);
    }

    memset(&server_addr,0,sizeof(struct sockaddr_in));
    
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(27351);
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);

    client_len = sizeof(struct sockaddr_in);

    if (bind(sock_fd, (struct sockaddr *)&server_addr, sizeof(struct sockaddr_in)) < 0){
        perror("bind error.\n");
        exit(1);
    }
	
	while (*parg) {
		rcv_num= recvfrom(sock_fd, rcv_buff, sizeof(rcv_buff), 0, (struct sockaddr*)&client_addr, &client_len);
        if (rcv_num>0 && rcv_buff[0] == 0x5A && rcv_buff[rcv_num-1]==0xA5) {
			/*   udp 协议格式 
			 *	 1B   1B     [0-n]B    1B
			 *  0x5A  cmd   param  0xA5
			 *   上位机---->设备
			 *  命令   参数   说明
			 *   1      无    设备发现命令
             *   2   	kv    按键模拟指令，kv取值 1， 2
             *   3      x     切换到相应的功能， x取值 0，1, 2
			 *   4      y     led8x8涂鸦功能 y对应led8x8缓存
             *   设备 ----> 上位机
			 *  0x81    v1,v2 设备发现命令响应,v1设备硬件版本版本，v2设备软件版本
			 */
			char cmd = rcv_buff[1]&0xff;
			int repLen = 0;
			if (cmd == 0x01) {
				int n = sprintf(&send_buff[2], "%s,%s", HW_VER,SW_VER);
				send_buff[0] = 0x5A;
				send_buff[1] = 0x81;
				send_buff[2+n] = 0xA5;
				repLen = 2 + n + 1;
			} else if (cmd == 0x02) {
				if (rcv_buff[2] == 1) {
					switchFun();
				} else if (rcv_buff[2] == 2) {
					sysStyle += 1;
				}
			} else if (cmd == 0x03) {
				int c = rcv_buff[2]&0xff;
				if (c >= 0 && c <= 2) {
					sysFun =  c;
					switchFun();
				}
			} else if (cmd == 0x04) {
				if (sysFun == 1) {
					led8x8Draw(&rcv_buff[2]);
					led8x8Flush();
				}
			}
			if (repLen > 0) {
				sendto(sock_fd , send_buff, repLen, 0, (struct sockaddr *)&client_addr, sizeof client_addr);
				repLen = 0;
			}
		}
	}
	close(sock_fd);
}
void demo(void)
{
	pthread_t tKey;
	pthread_t tAudionIn;
	pthread_t tRec;
	pthread_t tUdp;
	
	
	
	pwmLedInit();
	led8x8Init();
	oledInit();
	keyInit();
	
	switchFun();
	static int run = 1;
	
	pthread_create(&tRec, NULL, threadRecoder, &run );
	pthread_create( &tAudionIn, NULL, threadAudioIn, &run );

	pthread_create( &tKey, NULL, threadKey, &run );
	pthread_create( &tUdp, NULL, threadUdp, &run );
	while (1) sleep(1);
}