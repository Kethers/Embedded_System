#include <unistd.h>
#include <math.h>
#include "leds.h"
#include "utils.h"

#define DELAYMS 70
extern int sysStyle;
void *ledsDemo(void *arg)
{
	int *parg = arg;
	int ledidx = 0;
	int ledst = 0;
	int leddir = 1;
	int lastStyle = 0;
	ledInit();
	ledOff(0xff);
	while (*parg) {
		if (lastStyle != sysStyle) {
			lastStyle = sysStyle;
			if (sysStyle == 1) {
				leddir = -1;
			}
			if (sysStyle == 2) {
				leddir = 1;
			}
			ledOff(0xff);
		}
		if (ledst == 0) {
			ledidx += leddir;
			if (ledidx < 0) {
				if (sysStyle == 0) {
					leddir = -leddir;
					ledidx = 0;
				} else ledidx = 3;
			}
			if (ledidx > 3) {
				if (sysStyle == 0) {
					leddir = -leddir;
					ledidx = 3;
				}else ledidx = 0;
			}
			ledst = 1;
			ledOn(1<<ledidx);
		} else {
			ledOff(1<<ledidx);
			ledst = 0;
		}
		msleep(30);
	}
	ledOff(0xff);
}
	
int ledsTest(int argc, char *argv[])
{
	ledInit();
	while (1) {
		int i;
		for (i=0; i<=3; i++){
			ledOn(1<<i);
			msleep(DELAYMS);
			ledOff(1<<i);
		}
		for (i=3; i>=0; i--) {
			ledOn(1<<i);
			msleep(DELAYMS);
			ledOff(1<<i);
		}
	}
	return 0;
}

