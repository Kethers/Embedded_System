#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define DEVDIR "/sys/bus/i2c/devices/i2c-2/2-0070"

static unsigned short ram[8];

#if 0
static void dumRam(void)
{
	//printf("\033[2J");
	printf("\033[H");
	for(int i=0; i<8; i++) {
		for (int j=0; j<8; j++) {
			if (ram[i] & (1<<j)){
				printf("*");
			} else {
				printf(" ");
			}
		}
		printf("\r\n");
	}
}
#else
static void dumRam(void)
{
}
#endif
void led8x8Brightness(int b)
{
	char buf[128];
	snprintf(buf, 128, "echo \"%d\" > "DEVDIR"/brightness", b);
	system(buf);
}
void led8x8Point(int x, int y, int st)
{
	if (x>=0 && x<8){
		if (y>=0 && y<8) {
			ram[7-x] = ram[7-x] & ~(1<<(7-y));
			if (st != 0) {
				ram[7-x] = ram[7-x] | (1<<(7-y));
			}
		}
	}
}
void led8x8Draw(char *buf)
{
	for (int i=0; i<8; i++) {
		ram[i] = buf[i];
	}
}
void led8x8Clear(void)
{
	memset(ram, 0, sizeof ram);
}
void led8x8Flush(void)
{
	int fd = open(DEVDIR"/buffer", O_WRONLY);
	if (fd >= 0) {
		write(fd, ram, sizeof ram);
		close(fd);
	}
	dumRam();
}
void led8x8Init(void)
{
	if (0 == access("ht16k33.ko",F_OK)){
		int ret = system("lsmod | grep ht16k33");
		if (ret != 0) {
			system("insmod ht16k33.ko");
		}
	}
	memset(ram, 0, sizeof ram);
	led8x8Flush();
}



