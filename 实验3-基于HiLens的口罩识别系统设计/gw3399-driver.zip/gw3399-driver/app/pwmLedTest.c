#include <unistd.h>
#include <math.h>
#include "pwmLed.h"
#include "utils.h"
#define M_PI           3.14159265358979323846  /* pi */


void pwmLedSin(int Tms, int *run)
{
	int i;
	float t = Tms / 180.0f;
	for (i=0; i<=180&& *run; i+=1) {
		int v = sinf(i*M_PI/180)*1000;
		pwmLedValue(v);
		msleep(t);
	} 
}

void *pwmLedThread(void *arg)
{
	int *parg = arg;
	
	pwmLedInit();
	pwmLedPeriod(1000);
	pwmLedEnable(1);
	while (*parg) {
		pwmLedSin(3000, parg);
		for (int i=0; i<10&& *parg; i++) {
			msleep(100);
		}
	}
	return 0;	
}

int pwmLedTest(int argc, char *argv[])
{
	int run = 1;
	pwmLedThread(&run);
	return 0;
}

