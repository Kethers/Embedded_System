#include <sys/select.h> 
#include <string.h>
#include <sys/time.h>
void msleep(int ms)
{
	struct timeval delay;
	delay.tv_sec = ms/1000;
	delay.tv_usec = (ms%1000) * 1000; 
	select(0, NULL, NULL, NULL, &delay);
}

long sysms(void)
{
	struct timeval tv;
    gettimeofday(&tv,NULL);
	
    return tv.tv_sec*1000 + tv.tv_usec/1000; //毫秒
}