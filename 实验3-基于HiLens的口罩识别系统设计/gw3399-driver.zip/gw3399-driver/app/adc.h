#ifndef __ADC_H__
#define __ADC_H__

int adcReadRaw(int ch);
float adcReadCh0Volage(void);

#endif
