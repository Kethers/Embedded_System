﻿#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <getopt.h>
#include <unistd.h>
#include <pthread.h>  

#include "key.h"

typedef int (*app_t)(int argc, char *argv[]);

void demo(void);
int adcTest(int argc, char *argv[]);
int keyTest(int argc, char *argv[]);
int ledsTest(int argc, char *argv[]);
int led8x8Test(int argc, char *argv[]);
int oledTest(int argc, char *argv[]);
int oledTestFont(int argc, char *argv[]);
int pwmLedTest(int argc, char *argv[]);

static char *short_opts = "hl";
static struct option long_options[] = {
    {"help" ,no_argument , NULL , 'h'},
    {"list" , no_argument, NULL , 'l'},
    {NULL , 0 , NULL , 0}
};
static void help(char *name)
{
	printf("Usage: %s [function [arguments]...]\r\n", name);
    printf("or: %s --list[-l]\r\n",name);
	printf("or: %s --help[-h]\r\n",name);
    //printf("or: %s --install [-s] [DIR]\r\n", name);
    printf("or: function [arguments]...\r\n", name);
}

static struct {
	char *name;
	app_t fun;
} testApp[] = {
	{"adcTest", adcTest},
	{"keyTest", keyTest},
	{"led8x8Test", led8x8Test},
	{"ledsTest", ledsTest},
	{"oledTest", oledTest},
	{"oledTestFont", oledTestFont},
	{"pwmLedTest", pwmLedTest},
	{NULL,NULL}
};

static char *appName(char *name)
{
	char *pname = strrchr(name, '/');
	if (pname == NULL) pname = name;
	else pname += 1;
	return pname;
}
static app_t appInit(char *name)
{
	char *pname = appName(name);
	int ii = 0;
	while (testApp[ii].name != NULL) {
		if (0== strcmp(pname, testApp[ii].name)){
			return testApp[ii].fun;
		}
		ii += 1;
	}
	
	return NULL;
}
static void list(void)
{
	int ii = 0;
	while (testApp[ii].name != NULL) {
		printf("%s\r\n", testApp[ii].name);
		ii += 1;
	}
}
int main(int argc, char *argv[])
{
	app_t app;
	int opt;
	srand((int)time(0)); 
	app = appInit(argv[0]);
	if (app == NULL && argc > 1) {
		app = appInit(argv[1]);
		if (app != NULL) {
			argc -= 1;
			argv = &argv[1];
		}
	}
	if (app != NULL){
		return app(argc, argv);
	}
	while((opt = getopt_long(argc , argv, short_opts,  long_options, NULL)) != -1) {
		switch(opt) {
		case 'l':
			list();
			return 0;
		case 'h':
		default:
			help(appName(argv[0]));
			return 0;
		}
	}
	demo();	 
	return 0;
}