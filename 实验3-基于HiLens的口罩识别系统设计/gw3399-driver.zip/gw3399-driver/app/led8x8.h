#ifndef __LED_8X8_H__
#define __LED_8X8_H__

void led8x8Brightness(int b);
void led8x8Point(int x, int y, int st);
void led8x8Draw(char *buf);
void led8x8Clear(void);
void led8x8Flush(void);
void led8x8Init(void);

#endif
