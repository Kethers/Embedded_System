#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include "utils.h"
#include "key.h"

int keyTest(int argc, char *argv[])
{
	struct input_event t;
	keyInit();
	while (1) {
		t = keyCheck();
		if (t.type==EV_KEY) {
			printf("key: %d, value: %d\r\n", t.code, t.value);
		}
	}
	return 0;
}
