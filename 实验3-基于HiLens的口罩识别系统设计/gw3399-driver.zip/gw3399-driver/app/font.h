#ifndef __FONT_H__
#define __FONT_H__

void fontShow12(int x, int y, char* str, void (*df)(int,int,int));
void fontShow16(int x, int y, char* str, void (*df)(int,int,int));
#endif
