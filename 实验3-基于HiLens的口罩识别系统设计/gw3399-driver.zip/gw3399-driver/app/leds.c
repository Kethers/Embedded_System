#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "utils.h"

#include "pwmLed.h"

#define USE_PWMLED	1

void ledInit(void)
{
#if USE_PWMLED
	pwmLedInit();
	pwmLedPeriod(1000);
	pwmLedValue(0);
	pwmLedEnable(1);
#endif
}

void ledOn(int leds)
{
	char buf[128];
	int i;
	for (i=0; i<3; i++) {
		if ((leds & (1<<i)) != 0){
			snprintf(buf, 128, "echo 1 > /sys/class/leds/led%d/brightness", 3-i);
			system(buf);
		}
	}
#if USE_PWMLED
	if ((leds & (1<<3)) != 0){
		pwmLedPolarity(1);
	}
#endif
}
void ledOff(int leds)
{
	char buf[128];
	int i;
	for (i=0; i<3; i++) {
		if ((leds & (1<<i)) != 0){
			snprintf(buf, 128, "echo 0 > /sys/class/leds/led%d/brightness", 3-i);
			system(buf);
		}
	}
#if USE_PWMLED
	if ((leds & (1<<3)) != 0){
		pwmLedPolarity(0);
	}
#endif	
}