#include <unistd.h>
#include <math.h>
#include "led8x8.h"
#include "utils.h"
#include <stdlib.h>

static short faces[][8] = {
	{0x00, 0x66, 0x66, 0x00, 0x00, 0x7e, 0x00, 0x00},
	{0x00, 0x66, 0x66, 0x00, 0x00, 0x3c, 0x42, 0x3c},
	{0x42, 0xe7, 0x42, 0x00, 0x00, 0x3c, 0x42, 0x3c},
	{0x00, 0x66, 0x66, 0x00, 0x00, 0x3c, 0x24, 0x00},
	{0x00, 0xE7, 0x21, 0x00, 0x00, 0x42, 0x3c, 0x00},
	{0x00, 0xE7, 0x42, 0x00, 0x00, 0x42, 0x3c, 0x00},
	{0x00, 0xE7, 0x84, 0x00, 0x00, 0x42, 0x3c, 0x00},
	{0x00, 0x42, 0xa5, 0x00, 0x00, 0x24, 0x18, 0x00},
};

void led8x8Face(int i)
{
	if (i < sizeof faces / sizeof faces[0])
	{
		for (int j = 0; j < 8; j++)
		{
			for (int k = 0; k < 8; k++)
			{
				led8x8Point(k, j, faces[i][j] & (1 << k));
			}
		}
	}
}

int led8x8Test(int argc, char *argv[])
{
	led8x8Init();
	if (argc == 3)
	{
		int x = atoi(argv[1]);
		int y = atoi(argv[2]);
		led8x8Point(x, y, 1);
		led8x8Flush();
		return 0;
	}
	while (1)
	{
		int x = rand() % 8;
		int y = rand() % 8;
		led8x8Point(x, y, 1);
		led8x8Flush();
		msleep(200);
		led8x8Point(x, y, 0);
	}
	return 0;
}

void led8x8Ball(int c)
{
	int x = rand() % 8;
	int y = rand() % 8;
	int r = rand() % 4;
	int ax;
	int ay;
	int cnt = 0;

	led8x8Init();

	if (r == 0)
		ax = 1, ay = 1;
	if (r == 1)
		ax = 1, ay = -1;
	if (r == 2)
		ax = -1, ay = 1;
	if (r == 3)
		ax = -1, ay = -1;
	while (c == 0 || cnt < c * 4)
	{
		led8x8Point(x, y, 1);
		led8x8Flush();
		msleep(200);
		led8x8Point(x, y, 0);
		x += ax;
		y += ay;
		if (x < 0)
			ax = -ax, x = -x, cnt += 1;
		if (x > 7)
			ax = -ax, x = 7, cnt += 1;
		if (y < 0)
			ay = -ay, y = -y, cnt += 1;
		if (y > 7)
			ay = -ay, y = 7, cnt += 1;
	}
}
void *led8x8Thread(void *arg)
{
	int i = 0;
	led8x8Init();
	while (1)
	{
		led8x8Face(i);
		led8x8Flush();
		sleep(2);
		i = (i + 1) % (sizeof faces / sizeof faces[0]);
	}
}