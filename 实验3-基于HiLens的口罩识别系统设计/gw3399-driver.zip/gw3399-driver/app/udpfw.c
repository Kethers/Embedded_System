#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define SERV_PORT 27350

int main(int argc, char **argv)
{
	int sock_fd;
	char buf[2048];
	struct sockaddr_in addr;
	int ret;

	addr.sin_family = AF_INET;
    addr.sin_port = htons(27350);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	
    if ((sock_fd = socket(AF_INET, SOCK_DGRAM,0)) < 0)
    {
        perror("socket create error\n");
        exit(1);
    }
	while ((ret = read(0, buf, sizeof buf)) > 0) {
		sendto(sock_fd , buf, ret, 0, (struct sockaddr *)&addr, sizeof(addr));
	}

    close(sock_fd);
    return 0;
}
