#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>

#define USE_ADC_KEY   0	

#define DEVFILE  "/dev/input/by-path/platform-gpio-keys-event"

static int devFd = -1;

static struct input_event keyEventCheck(void)
{
	struct input_event t;
	if (devFd >= 0){
		struct timeval tv;
		fd_set rset;
		
		tv.tv_sec = 0;
		tv.tv_usec = 20;
		FD_ZERO(&rset);   
		FD_SET(devFd, &rset);   
		select(devFd+1, &rset, NULL, NULL, &tv);
		if(FD_ISSET(devFd, &rset)){
			if (read(devFd, &t, sizeof(t)) == sizeof(t)){
				if(t.type==EV_KEY && t.value != 2){
					return t;
				}
			}
		}
	}
	memset(&t, 0, sizeof t);
	return t;
}

#if USE_ADC_KEY
#include "adc.h"
static int adcKey = 0;
struct input_event keyCheck(void)
{
	struct input_event t;
	int v1, v2;
	v1 = adcReadRaw(1);
	t = keyEventCheck();
	if (t.type==EV_KEY){
		return t;
	}
	v2 = adcReadRaw(1);
	if (v1 > 900 && v2 > 900 && adcKey == 1) {
		adcKey = 0;
		t.type = EV_KEY;
		t.value = 0;
		t.code = KEY_2;
	} 
	if (v1 < 100 && v2 < 100 && adcKey == 0) {
		adcKey = 1;
		t.type = EV_KEY;
		t.value = 1;
		t.code = KEY_2;
	}
	return t;
}
#else
struct input_event keyCheck(void)
{
	return keyEventCheck();
}	
#endif
void keyInit(void)
{
#if USE_ADC_KEY
	adcKey = 0;
#endif
	if (devFd < 0) {
		devFd = open(DEVFILE, O_RDONLY);
	}
}

void keyDeInit(void)
{
	if (devFd >= 0) {
		close(devFd);
		devFd = -1;
	}
}
