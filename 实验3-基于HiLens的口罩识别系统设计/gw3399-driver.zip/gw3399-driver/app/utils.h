#ifndef __UTILS_H__
#define __UTILS_H__

void msleep(int ms);
long sysms(void);

#endif
