#include <unistd.h>
#include <math.h>
#include <stdlib.h>
#include "oled.h"
#include "utils.h"
#include "font.h"

int oledTest(int argc, char *argv[])
{
	oledInit();

	while (1) {
		int x = rand()%96;
		int y = rand()%32;
		oledPoint(x, y, 1);
		oledFlush();
		msleep(200);
		oledPoint(x, y, 0);
	}
	return 0;
}
int oledTestFont(int argc, char *argv[])
{
	oledInit();
	fontShow16(16,8, "Welcome!", oledPoint);
	oledFlush();
	return 0;
}