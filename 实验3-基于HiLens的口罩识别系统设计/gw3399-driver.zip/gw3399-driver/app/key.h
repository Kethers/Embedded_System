#ifndef __KEY_H__
#define __KEY_H__

#include <linux/input.h>

void keyInit(void);
struct input_event keyCheck(void);
void keyDeInit(void);

#endif
