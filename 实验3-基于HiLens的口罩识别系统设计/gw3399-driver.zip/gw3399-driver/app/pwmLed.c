﻿#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "utils.h"

#define PWM_DIR "/sys/class/pwm/pwmchip1/pwm0"

#if 0
#define dbg(x...) do{printf(x);printf("\r\n");}while(0)
#else
#define dbg(x...) do{}while(0)	
#endif

void pwmLedPeriod(int p)
{
	char buf[128];
	snprintf(buf, 128, "echo \"%d\" > "PWM_DIR"/period",p*1000);
	dbg(buf);
	system(buf);
}

void pwmLedValue(int v)
{
	char buf[128];
	snprintf(buf, 128, "echo \"%d\" > "PWM_DIR"/duty_cycle",v*1000);
	dbg(buf);
	system(buf);
}

void pwmLedPolarity(int p)
{
	char buf[128];
	char* v[] = {"normal", "inversed"};
	p = !!p;	
	snprintf(buf, 128, "echo %s > "PWM_DIR"/polarity",v[p]);
	dbg(buf);
	system(buf);	
}

void pwmLedEnable(int en)
{
	char buf[128];
	snprintf(buf, 128, "echo \"%d\" > "PWM_DIR"/enable", !!en);
	dbg(buf);
	system(buf);	
}

void pwmLedInit(void)
{
	if (0 != access(PWM_DIR,F_OK)) {
		system("echo \"0\" > /sys/class/pwm/pwmchip1/export");
	} 
	pwmLedPeriod(1000);
	pwmLedEnable(0);
	pwmLedValue(0);
	pwmLedPolarity(0);
	
}
