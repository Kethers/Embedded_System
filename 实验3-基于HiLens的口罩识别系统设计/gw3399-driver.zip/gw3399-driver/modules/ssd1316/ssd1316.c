/*头文件*/
#include<linux/init.h>
#include<linux/module.h>
#include<linux/sched.h>
#include<linux/kernel.h>
#include <asm/uaccess.h>
#include <linux/gpio.h>
#include <linux/cdev.h>
#include <linux/fs.h>    
#include <linux/device.h>
#include <linux/i2c.h>
#include <linux/device.h>
#include <asm/device.h>
#include <linux/workqueue.h> 

#include <linux/jiffies.h>

#define  DEVICE_RS	1

#define USE_DEVFS	0

#define dbg(a...)  printk(a)



#define DEVICE_NAME	"ssd1316"

#if DEVICE_RS
#define DEV_I2C_BUS       2 
#define DEV_I2C_ADDRESS   (0x78>>1)


static int dev_i2c_register(void)
{
	// TODO: 注册I2C设备
	// 
}

#endif
#define CMD_LED_ON	0xAF
#define CMD_LED_OFF	0xAE

static char led_buf[4][96];

static struct i2c_client *i2c_dev;

static int ssd1316_write_command(char c)
{
	char cmd[] = // TODO: 填充CMD字段
	return i2c_master_send(i2c_dev, cmd, 2);
}
static int ssd1316_write_data(char *p)
{
	char cmd[97];
	// TODO: 填充CMD字段
	// 

	return i2c_master_send(i2c_dev, cmd, 97);
}
static void ssd1316_flush(void)
{
	for (int m = 0; m < 4; m++) {
		ssd1316_write_command(0xb0 + m);
		ssd1316_write_command(0x00);
		ssd1316_write_command(0x10);
		ssd1316_write_data(led_buf[m]);	
	}
}


ssize_t buffer_read(struct file *f, struct kobject *k, struct bin_attribute *a,
                        char *buf, loff_t of, size_t len)
{
	// TODO
	// 
}
ssize_t buffer_write(struct file *f, struct kobject *k, struct bin_attribute *a,
                         char *buf, loff_t of, size_t len)
{
	// TODO
	// 
}

static  BIN_ATTR_RW(buffer, 4*96);


static int dev_i2c_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int ret;

	dbg(DEVICE_NAME":dev_i2c_probe()\r\n");
	i2c_dev = client;
	//check device is connect ok!
	memset(led_buf, 0, sizeof led_buf);

	// TODO: 对OLED进行初始化
	// 

	ssd1316_flush();

	ssd1316_write_command(CMD_LED_ON);

	
	ret = device_create_bin_file(&client->dev, &bin_attr_buffer);
	if (ret < 0) {
		printk(DEVICE_NAME":error create bin file\r\n");
		return -1;	
	}
   
	return 0;
}
static int dev_i2c_remove(struct i2c_client *client)
{
	dbg(DEVICE_NAME":dev_i2c_remove()\r\n");
	
	device_remove_bin_file(&client->dev, &bin_attr_buffer);
	ssd1316_write_command(CMD_LED_OFF);

	return 0;
}
static const struct i2c_device_id dev_i2c_id[] = {
    // TODO
	// 
};
static struct i2c_driver dev_i2c_driver = {
	// TODO
	// 
};

static int __init dev_init(void)
{
	// TODO
	// 
}

static void __exit dev_exit(void)
{
	// TODO
	// 
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION(DEVICE_NAME" driver");

module_init(dev_init);
module_exit(dev_exit);


